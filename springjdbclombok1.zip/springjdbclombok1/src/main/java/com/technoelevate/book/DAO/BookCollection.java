package com.technoelevate.book.DAO;

import java.util.List;

import com.technoelevate.book.DTO.BookDTO;

public interface BookCollection {
	public BookDTO validate(int id, String name);
	
	public BookDTO getBooks(int id);
	
	public  boolean  deleteBooks(int id);
	
	public boolean addBooks(BookDTO bookdto);
	
	public boolean updateBooks(BookDTO bookdto);
	
	public List<BookDTO> getAllBooks();
	
	
}
