package com.technoelevate.book.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.technoelevate.book.DTO.BookDTO;


public class RowMapperImpl implements RowMapper<BookDTO> {

	@Override
	public BookDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		BookDTO bookdto = new BookDTO();
		bookdto.setBookId(rs.getInt(1));
		bookdto.setBookName(rs.getString(2));
		bookdto.setAuthorName(rs.getString(3));
		
		return bookdto;
	}

	

}
