package com.technoelevate.book.Serviece;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.technoelevate.book.DTO.BookDTO;

public class BookJdbc {
	ApplicationContext context = new ClassPathXmlApplicationContext("com/technoelevate/book/Serviece/config.xml");
	BookServieceImpl book = context.getBean("book", BookServieceImpl.class);

	public boolean addBooks(BookDTO bookdto) {
		return book.addBooks(bookdto);
	}

	public boolean validate(int id, String name) {
		BookDTO bookName = book.validate(id, name);
		if (name.equals(bookName)) {
			return true;
		} else
			return false;
	}

	public List<BookDTO> getAllBooks() {
		return book.getAllBooks();
	}
	
	public  boolean  deleteBooks(int id) {
		boolean bookName = book.deleteBooks(id);
		return false;
		
	}
	
	public boolean updateBooks(BookDTO bookdto) {
		
		return book.updateBooks(bookdto);
		
	}
}
