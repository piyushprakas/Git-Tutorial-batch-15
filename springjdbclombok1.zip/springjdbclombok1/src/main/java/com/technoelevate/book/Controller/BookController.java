package com.technoelevate.book.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.technoelevate.book.DTO.BookDTO;
import com.technoelevate.book.Serviece.BookJdbc;
@Controller
public class BookController {
	@Autowired
	BookJdbc book; 
	
  @GetMapping("/home")
  public String homepage() {
	  return "Homepage";
	  
  }
  
	  
@GetMapping("/allbooks")
public String getAllBooks(ModelMap map,BookDTO bookdto) {
	List<BookDTO> allBooks = book.getAllBooks();
	map.addAttribute("AllBooks",allBooks);
	return "BookList";
}

@GetMapping("/add")
public String addBook() {
	return "AddBook";
}

@PostMapping("/add")
public String addBook(ModelMap map, BookDTO bookdto) {
	if (bookdto != null) {
		book.addBooks(bookdto);
		map.addAttribute("Mybook", bookdto);
		map.addAttribute("msg", "book added");
	} else {

		map.addAttribute("msg", "book not added");
	}
	return "BookRack";
}
	 

@GetMapping("/validate")
public String validateBooks() {
	return "Bookvalid";
}

@PostMapping("/validate")
public String validateBooks(ModelMap map, BookDTO bookdto) {
	if (book.validate(bookdto.getBookId(), bookdto.getBookName())) {
		map.addAttribute("id", bookdto);
		map.addAttribute("msg", "correct book name");
	} else {
		map.addAttribute("msg", "wrong book name");
	}
	System.out.println(bookdto.getBookName());
	return "Validbook";

}


@GetMapping("/logout")
public String logout(HttpSession session) {
	session.invalidate();
	return "Homepage";
}
}

