package com.technoelevate.book.Serviece;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.technoelevate.book.DAO.BookCollection;
import com.technoelevate.book.DTO.BookDTO;

public class BookServieceImpl implements BookServiece {
@Autowired
	BookCollection collection;
	
	@Override
	public BookDTO validate(int id, String name) {
		if(id<0) {
		return null;
		}
		return collection.validate(id, name);
	}

	@Override
	public BookDTO getBooks(int id) {
		if(id<0) {
			return null;
			}
			return collection.getBooks(id);
	}

	@Override
	public boolean deleteBooks(int id) {
		if(id<0) {
			return false;
			}
			return collection.deleteBooks(id);
	}

	@Override
	public boolean addBooks(BookDTO bookdto) {
		
			return collection.addBooks(bookdto);
	}

	@Override
	public boolean updateBooks(BookDTO bookdto) {
		return collection.updateBooks(bookdto);
	}

	@Override
	public List<BookDTO> getAllBooks() {
		return collection.getAllBooks();
	}

}
