package com.technoelevate.book.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


import com.technoelevate.book.DTO.BookDTO;

public class BookDAO {
	
	JdbcTemplate template ;
	
   public void setTemplate(JdbcTemplate template) {
	   this.template = template;
   }
   
   public int addBooks(BookDTO bookdto) {
	   String query = "INSERT INTO book_info VALUES(?,?,?)";
       int result = template.update(query,bookdto.getBookId(),bookdto.getBookName(),bookdto.getAuthorName());
       return result;
   }
   
   public List<BookDTO> getAllBooks(){
	   RowMapper<BookDTO> rowMapper = new RowMapperImpl();
	   String query = "SELECT * FROM book_info";
	   List<BookDTO> books = template.query(query,rowMapper);
	   return books;
   }
   
   public BookDTO validate(int id, String name) {
		RowMapper<BookDTO> rowMapper = new RowMapperImpl();
		String query="SELECT * FROM book_info WHERE name =?";
		BookDTO book=template.queryForObject(query,rowMapper,name);
		return book;
		
	}
   
	public boolean deleteBooks(int id) {
		RowMapper<BookDTO> rowMapper = new RowMapperImpl();
		String query="DELETE  FROM book_info WHERE name =?";
		BookDTO book=template.queryForObject(query,rowMapper,id);
		return true;
	}

	public boolean updateBooks(BookDTO bookdto) {
		 String query = "INSERT INTO book_info VALUES(?,?,?)";
	       int result = template.update(query,bookdto.getBookId(),bookdto.getBookName(),bookdto.getAuthorName());
	       return true;
	}
}
